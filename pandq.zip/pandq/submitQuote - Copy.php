<?php 
//if(isset($_POST['productSelectedArr']))
//{
////	echo "<pre>";
////print_r($_POST);
////die();
//
//
////echo count($a);
//	
//	
//            //[image] => assets/images/quote/shirt.png
//            //[name] => T-Shirt
//            //[quantity] => 6
//	
//		
//			
//				
//
//echo "<pre>";
//print_r($a);
//echo "</pre>";
//}


//die();

	$productSelectedArr = $_POST['productSelectedArr'];
//$a = (json_decode($productSelectedArr));


// $p_name = $_POST['p_name'];
// $p_quantity = $_POST['p_quantity'];

// File upload path
//$targetDir = "assets/uploads/";
//$fileName = basename($_FILES["file"]["name"]);
//$targetFilePath = $targetDir . $fileName;
//$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

$name = $_POST['name'];
$email = $_POST['email'];
$phonenumber = $_POST['phonenumber'];

$to = "david.markk611@gmail.com";


$subject = "Quotation Request";
//$message = "Thsi is post message data".print_r($_POST);
$a = (json_decode($productSelectedArr));

print_r($a);
$formarray = ['name'=>$name, 'email'=>$email, 'number'=>$phonenumber];

//$message = file_get_contents('email-template1.php' ,$formarray, $productSelectedArr ,true);
$body = file_get_contents('email-template1.php');

//echo $message;
//die();
 //$formarray;
print_r($formarray);
//echo "<br>";
//die();
$message = str_replace($formarray, $productSelectedArr ,$body);

//echo($message);


$header = "From: .$email \r\n";
$header .= "MIME-Version: 1.0\r\n";
$header .= "Content-type: text/html\r\n";

$retval = mail($to,$subject,$message,$header);

if($retval)
{
	echo "Message sent successfully...";
}
else
{
	echo "Message could not be sent...";
}



die();



?>