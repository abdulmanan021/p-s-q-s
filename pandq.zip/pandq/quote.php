<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- My Custom CSS -->
    <link href="assets/extracss/mycss.css" rel="stylesheet">
	  
    <!-- Jquery -->
    <script src="jquery/jquery.min.js"></script>

    <title>P's & Q's Printing</title>

  </head>
  <body>

     <div class="container-fluid navbg navbar-pos pt-2 pb-3">
			
			<div class="row justify-content-between">
				
				<div class="col-md-6 d-flex">
					<a class="navbar-brand" href="index.php">
						<img src="assets/images/logo.png" class="img-fluid" width="160">
					  </a>
					<a class="nav-link d-flex ml-auto" href="tel">
						<?php /*?><img src="assets/images/callicon.png" class="img-fluid" width="30"><?php */?>
						<p class="text-white my-auto p-2">202-555-0194</p>
					</a>
				</div>
				<div class="col-md-4 nodsp">
					<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
					  <div class="carousel-inner">
						<div class="carousel-item active">
							<p class="text-justify text-white">
								Ps and Qs is world best printing service, Professional staff and qualitywork delivered. 
							</p>
							<div class="d-flex text-white justify-content-between">
								<h6 class="fw-bold my-auto">John M</h6>
								<p class="my-auto">CEO</p>
								<p class="my-auto">Q Mobile</p>
							</div>
						</div>
						<div class="carousel-item">
						  <p class="text-justify text-white">
								Ps and Qs is world best printing service, Professional staff and qualitywork delivered. 
							</p>
							<div class="d-flex text-white justify-content-between">
								<h6 class="fw-bold my-auto">John M</h6>
								<p class="my-auto">CEO</p>
								<p class="my-auto">Q Mobile</p>
							</div>
						</div>
						<div class="carousel-item">
						  <p class="text-justify text-white">
								Ps and Qs is world best printing service, Professional staff and qualitywork delivered. 
							</p>
							<div class="d-flex text-white justify-content-between">
								<h6 class="fw-bold my-auto">John M</h6>
								<p class="my-auto">CEO</p>
								<p class="my-auto">Q Mobile</p>
							</div>
						</div>
					  </div>
					  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true" style="visibility: hidden;"></span>
						<span class="visually-hidden">Previous</span>
					  </button>
					  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true" style="visibility: hidden;"></span>
						<span class="visually-hidden">Next</span>
					  </button>
					</div>
				</div>
			
			</div>
          
          <?php /*?><button class="navbar-toggler navbar-light bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
            <ul class="navbar-nav">
              <li class="nav-item my-auto">
                <a href="#" class="nav-link text-white aboutbtn">About Us</a>
              </li>
              <li class="nav-item my-auto">
                <a href="#" class="nav-link text-white faqbtn">FAQ's</a>
              </li>
              <li class="nav-item my-auto">
                <a href="#" class="nav-link text-white contactbtn">Contact Us</a>
              </li>
            </ul>
          </div><?php */?>
        </div>


    <div class="container">


      <!-- Circles which indicates the steps of the form: -->
      <?php /*?><div style="text-align:center;margin-top:60px; margin-bottom: 40px; visibility: hidden;">
        <span class="step"></span>
        <span class="step"></span>
        <span class="step"></span>
        <span class="step"></span>
      </div><?php */?>

      <form id="regForm" method="POST">
        <!-- One "tab" for each step in the form: -->
        <?php 
        
          $prductArr = array(
            array("image" => "assets/images/quote/shirt.png", "name" => "T-Shirt" ),
            array("image" => "assets/images/quote/blackshirt.png", "name" => "Shirt" ),
            array("image" => "assets/images/quote/bag.png", "name" => "Bag" ),
            array("image" => "assets/images/quote/towel.png", "name" => "towel" ),
            array("image" => "assets/images/quote/ladiesbag.png", "name" => "Ladies Bag" ),
            array("image" => "assets/images/quote/towel2.png", "name" => "Towel" ),
            array("image" => "assets/images/quote/shirt.png", "name" => "T-Shirt" ),
            array("image" => "assets/images/quote/blackshirt.png", "name" => "Shirt" ),
            array("image" => "assets/images/quote/ladiesbag.png", "name" => "Ladies Bag" ),
          );
        
        
        ?>
     
	  	<div class="tab">
      
          <div class="row colreverse justify-content-between">
			  <div class="col-md-9">
				  <div class="row">
					  <?php 
						$n=1; 
						  foreach($prductArr as $k=>$v){
							echo '
							<div class="col-xl-4 col-lg-6 col-md-6 mt-3 productNo'.$n.'" id="productNo'.$n.'">
							<div class="card cardstyle">
							  <div class="custom-control mycheck custom-checkbox image-checkbox">
								<label class="custom-control-label" for="towel3">
								  <img src="'.$v['image'].'" alt="#" class="d-block mx-auto img-fluid" id="productImage'.$n.'">
								</label>'.
			//                    <div class="d-flex p-3 justify-content-between">
			//                      <input type="checkbox" class="custom-control-input my-auto" value="'.$n.'" name="productSelected[]" id="quotationProducts" 
			//                       onchange="productChecked(this, '.$n.')"
			//                      >
			//                    </div>
								'<p class="my-auto fw-bold text-center" id="productName'.$n.'">'.$v['name'].'</p>
							  </div>
							  <div class="card-footer" style="background-color: #00a5ba;">
								<div class="row justify-content-between">
								  <div class="col-md-6 my-auto">
									<div class="input-group input-group-sm">'.
									  //<button type="button" class="btn w-25 btn-outline-secondary" id="minus'.$n.'">-</button>
									  '<input type="text" class="form-control text-center inputstyle1" id="quantity'.$n.'" name="quantity'.$n.'">'.
									  //<button type="button" class="btn w-25 btn-outline-secondary"  id="add'.$n.'" >+</button>
									'</div>
								  </div>
								  <div class="my-auto col-md-6 text-center">
									<p class="my-auto text-white" style="font-size:14px;">Enter Quantity</p>
								  </div>
								</div>
								<hr style="background:white;">
								<div class="row justify-content-between">
								  <div class="col-md-6">
								  	<div class="input-group input-group-sm">'.
									  //<button type="button" class="btn w-25 btn-outline-secondary" id="minus'.$n.'">-</button>
									  '<div class="btn-group mx-auto" role="group" aria-label="Basic checkbox toggle button group">
										  <input type="checkbox" class="btn-check" id="" autocomplete="off">
										  <label class="btn btn-outline-light" for="">S</label>

										  <input type="checkbox" class="btn-check" id="" autocomplete="off">
										  <label class="btn btn-outline-light" for="">M</label>

										  <input type="checkbox" class="btn-check" id="" autocomplete="off">
										  <label class="btn btn-outline-light" for="">L</label>

										  <input type="checkbox" class="btn-check" id="" autocomplete="off">
										  <label class="btn btn-outline-light" for="">XL</label>
										</div>'.
									  //<button type="button" class="btn w-25 btn-outline-secondary"  id="add'.$n.'" >+</button>
									'</div>
									</div>
								  <div class="my-auto col-md-6 text-center">
									<p class="my-auto text-white" style="font-size:14px;">Size</p>
								  </div>
								</div>
								<hr style="background:white;">
								<div class="row justify-content-between">
								  <div class="col-md-6 my-auto">
									'.
									  //<button type="button" class="btn w-25 btn-outline-secondary" id="minus'.$n.'">-</button>
									  '<div class="d-flex my-auto justify-content-between">
										  <input type="color" class="colrpick" name="favcolor" value="#ffffff" disabled>
										  <input type="color" class="colrpick" name="favcolor" value="#000" disabled>
										  <input type="color" class="colrpick" name="favcolor" value="#f90901" disabled>
										  <input type="color" class="colrpick" name="favcolor" value="#0400FA" disabled>
										  <input type="color" class="colrpick" name="favcolor" value="#03FC0B" disabled>
									  </div>
									  '.
										//
									  //<button type="button" class="btn w-25 btn-outline-secondary"  id="add'.$n.'" >+</button>
									'
								  </div>
								  <div class="my-auto col-md-6 text-center">
									<p class="my-auto text-white" style="font-size:14px;">Available Color</p>
								  </div>
								</div>
							  </div>
							</div>
						  </div>';
						  $n++;
						  }

						?>
				  </div>
			  </div>
			  <div class="col-md-3 colstyle">
				  <button type="button" class="btn text-white w-100 btnsubmit mt-3 nextBtn" style="background-color: #e94696; position: sticky; top: 50%;" onclick="nextPrev(1)">Choose Graphics</button>
			  </div>
          </div>

        </div>
        
        <div class="tab">
          <div class="row justify-content-center">
            <div class="col-lg-7 col-md-10 mt-5" style="margin-top: 150px !important; margin-bottom: 200px !important">
              <div class="card p-3 mt-5 cardstyle1">
                <h4 class="fw-bold text-center">Upload Graphics</h4>
                <hr class="mx-auto hrcolr">
				  <div class="row">
					  <div class="col-md-3">
						  <div class="card alert alert-dismissible fade show" role="alert" style="padding: 0px;">
							  <img src="assets/images/quote/shirt.png" class="img-fluid" alt="" width="400">
						  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" style="padding: 1px;"></button>
						</div>
					  </div>
					  <div class="col-md-3">
						  <div class="card alert alert-dismissible fade show" role="alert" style="padding: 0px;">
							  <img src="assets/images/quote/bag.png" class="img-fluid" alt="" width="400">
						  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" style="padding: 1px;"></button>
						</div>
					  </div>
					  <div class="col-md-3">
						  <div class="card alert alert-dismissible fade show" role="alert" style="padding: 0px;">
							  <img src="assets/images/quote/blackshirt.png" class="img-fluid" alt="" width="400">
						  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" style="padding: 1px;"></button>
						</div>
					  </div>
					  <div class="col-md-3">
						  <div class="card alert alert-dismissible fade show" role="alert" style="padding: 0px;">
							  <img src="assets/images/quote/towel2.png" class="img-fluid" alt="" width="400">
						  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" style="padding: 1px;"></button>
						</div>
					  </div>
				  </div>
                <input class="form-control inputstyle p_graphics" type="file" id="p_graphics" name="p_graphics">
				  <div class="d-flex justify-content-between">
                  <div class="col-md-5 d-block">
                    <button type="button" class="btn w-100 btnsubmit mt-5 prevBtn" style="background-color: gray !important;" onclick="nextPrev(-1)">Return to Garments</button>
                  </div>
                  <div class="col-md-5">
                    <button type="button" class="btn w-100 btnsubmit mt-5 nextBtn" style="background-color: #e94696;" onclick="nextPrev(1)">Get Quote</button>
                  </div>
                </div>
                <?php /*?><button type="button" class="btn btnsubmit mt-5 nextBtn" onclick="nextPrev(1)">Get Quote</button><?php */?>
              </div>
            </div>
          </div>
        </div>
        
        <div class="tab">
          <div class="row justify-content-center mt-5">
            <div class="col-lg-7 col-md-10 mt-5">
              <div class="card p-3 cardstyle1">
                <h4 class="fw-bold text-center">Personal Information</h4>
                <hr class="mx-auto hrcolr">
                <input class="form-control mt-4 inputstyle" type="text" placeholder="Name" id="name" name="name" required>
                <input class="form-control mt-4 inputstyle" type="email" placeholder="Email" id="email" name="email" required>
                <input class="form-control mt-4 mb-4 inputstyle" type="tel" placeholder="Phone Number" id="phonenumber" name="phonenumber" required>
				  <div class="g-recaptcha ml-auto" data-sitekey="6Ld68FIbAAAAADqOVyGSBYBdpoeSg7FJERN03T2X"></div>
                <div class="d-flex justify-content-between">
                  <div class="col-md-5 d-block">
                    <button type="button" class="btn w-100 btnsubmit mt-5 prevBtn" style="background-color: gray !important;" onclick="nextPrev(-1)">Garments</button>
                  </div>
                  <div class="col-md-5">
                    <button type="button" class="btn w-100 btnsubmit mt-5 nextBtn" style="background-color: #e94696;" onclick="nextPrev(1)" id="submitbutton" >Get Quote</button>
                  </div>
                </div>
                <?php /*?><button type="button" class="btn btnsubmit mt-5 nextBtn" onclick="nextPrev(1)">Get Quote</button><?php */?>
				  
				  
				  
              </div>
            </div>
          </div>
			
        </div>
        
        <div class="tab">
          <div class="row justify-content-center mt-5">
            <div class="col-md-7 mt-5">
              <div class="card p-3 cardstyle1">
                <h4 class="fw-bold text-center">Thank You</h4>
                <hr class="mx-auto hrcolr">
                <img src="assets/images/quote/done.png" class="img-fluid mx-auto mt-3 mb-5" width="100">
                <div class="alert alert-success text-center" role="alert">
                  We will be in contact
                </div>
                <a href="index.php" class="btn btnsubmit text-white">Back to Home</a>
              </div>
            </div>
          </div>
        </div>
        
        <div style="overflow:hidden;">
          <div style="float:right;">
            <button type="button" class="btn btnsubmit mt-5 prevBtn firstButton" onclick="nextPrev(-1)">Previous</button>
            <button type="button" class="btn btnsubmit mt-5 nextBtn secondButton" onclick="nextPrev(1)">Get Quote</button>
          </div>
        </div>
        
      </form>
    </div>

    <!--  Footer -->
    <footer>
      <div class="container-fluid pt-5 pb-5 footbg">
        <div class="row justify-content-between">
          <div class="col-md-3">
            <a href="index.php">
              <img src="assets/images/logo.png" class="img-fluid" width="200">
            </a>
          </div>
          <?php /*?><div class="col-md-3">
            <h5 class="fw-bold mt-2 mb-2">Quick Links</h5>
            <a href="index.php#home" class="nav-link text-white homebtn">Home</a>
            <a href="index.php#aboutus" class="nav-link text-white aboutbtn">About Us</a>
            <a href="index.php#faq" class="nav-link text-white faqbtn">FAQ's</a>
            <a href="index.php#conatctus" class="nav-link text-white contactbtn">Contact Us</a>
          </div>
          <div class="col-md-3">
            <h5 class="fw-bold mt-2 mb-2">Contact us</h5>
            <p class="text-white text-justify">Phone: 202-555-0194</p>
            <p class="text-white text-justify">Email: example@email.com</p>
            <address>
              <p class="text-white">Address: Your address here</p>
            </address>
          </div><?php */?>
          <div class="col-md-6">
            <h5 class="fw-bold mt-2 mb-2 text-center">Follow Us</h5>
            <div class="row justify-content-center">
              <div class="col-md-2 text-center mt-3">
                <a href="#"><img src="assets/images/icons/facebook.png" class="img-fluid" width="50"></a>
              </div>
              <div class="col-md-2 text-center mt-3">
                <a href="#"><img src="assets/images/icons/twitter.png" class="img-fluid" width="50"></a>
              </div>
              <div class="col-md-2 text-center mt-3">
                <a href="#"><img src="assets/images/icons/instagram.png" class="img-fluid" width="50"></a>
              </div>
              <div class="col-md-2 text-center mt-3">
                <a href="#"><img src="assets/images/icons/pintrest.png" class="img-fluid" width="50"></a>
              </div>
              <div class="col-md-2 text-center mt-3">
                <a href="#"><img src="assets/images/icons/whatsapp.png" class="img-fluid" width="50"></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>

	  
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
	  
    <script>
      $(document).ready(function() {
      $(".homebtn").click(function() {
          $('html, body').animate({
              scrollTop: $("#home").offset().top
          }, 1000);
      });

      $(".aboutbtn").click(function() {
          $('html, body').animate({
              scrollTop: $("#aboutus").offset().top
          }, 1000);
      });

      $(".faqbtn").click(function() {
          $('html, body').animate({
              scrollTop: $("#faq").offset().top
          }, 1000);
      });

      $(".contactbtn").click(function() {
          $('html, body').animate({
              scrollTop: $("#conatctus").offset().top
          }, 1000);
      });

      });
      var arr = new Array();
      function productChecked(v, n){
        if(v.checked) {
          arr.push(n);
        }else{
          var i =  arr.indexOf(n);
          arr.splice(i, 1);
        }
      }
    </script>

<script>
          //FORM

var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
 // alert(n);
  if(n == 0){
    $(".prevBtn").hide();
  }else{
    $(".prevBtn").show();
  }
	
    $(".firstButton").hide();
    $(".secondButton").hide();
  
  if(n==3){
//     $.ajax({
//       type : 'POST',
//       url : 'submitQuote.php',
//       data : $('#regForm').serialize(),
//       success: function (data) {
        
//       }
// });

   
	 //var youtubeimgsrc = document.getElementById("P_graphics").src;
	  
    //var sfi = $('#p_graphics').src;
	//console.log(sfi);
	  //alert(youtubeimgsrc);
    var name = $('#name').val();
    var email = $('#email').val();
    var phonenumber = $('#phonenumber').val();
    //var p_graphics = $('#p_graphics').val();
//	  const [file] = p_graphics.files
//  if (file) {
//    p_graphics.src = URL.createObjectURL(file)
//	    alert(file);
//  }
	// p_graphics.src = URL.createObjectURL(file)
	

		var formData = new FormData();

    var productSelectedArr = new Array();
    for(var i = 0; i < (arr.length); i++){
      var getImage, getName, getQuantity;

      getImage = $("#productImage"+arr[i]).attr("src");

      getName=  $("#productName"+arr[i]).text();

      getQuantity = $("#quantity"+arr[i]).val();

      productSelectedArr[i] = {
        "image" : getImage,
        "name" : getName,
        "quantity" : getQuantity
      };
      
    // alert(arr[i]+ "image is: "+getImage+ "---> getName : "+getName+" --> getQuantity: "+getQuantity);

    }

    console.log(productSelectedArr);
    var jsonS = JSON.stringify(productSelectedArr);
    //alert(jsonS);
    formData.append('productSelectedArr', jsonS);

    //formData.append('p_graphics', $('form#regForm').find('input.p_graphics')[0].files[0]);

    //formData.append('p_graphics',p_graphics);
    formData.append('name', name);
    formData.append('email', email);
    formData.append('phonenumber', phonenumber);

			$.ajax({
				url: "submitQuote.php",
				//url: "email-template1.php",
				type: "POST",
				data: formData,
				cache: false,
        processData: false,
        contentType: false,
        dataType:'json',
				success: function(res){
					showMessage(res.status,res.message);
					//var dataResult = JSON.parse(dataResult);
					if(res.statusCode==200){
						
            //alert("yes");
						//$('.success_div').show();
						// $('#nextBtn').hide();	
						// x[2].style.display = "none";
						// x[3].style.display = "block";
						
						
					}else if(res.statusCode==201){
						//alert('please enter your pin');
						
					}  else if(res.statusCode==205){
						// $('#nextBtn').hide();
						
					}
					
				},
				 complete: function (res) {
           $('#name').val('');
           $('#email').val('');
           $('#phonenumber').val('');
           
            
        }  
			});

  
  }
  // This function will display the specified tab of the form ...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  // ... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementsByClassName("prevBtn").style.display = "none";
  } else {
    document.getElementsByClassName("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementsByClassName("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementsByClassName("nextBtn").innerHTML = "Next";
  }

  // ... and run a function that displays the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  //if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  // if (currentTab >= x.length-1)
  // {
  //   //...the form gets submitted:
  //   document.getElementById("regForm").submit();
  //   showTab(x.length-1);
  //   return false;
  // }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

// function validateForm() {
//   // This function deals with validation of the form fields
//   var x, y, i, valid = true;
//   x = document.getElementsByClassName("tab");
//   y = x[currentTab].getElementsByTagName("input");
//   // A loop that checks every input field in the current tab:
//   for (i = 0; i < y.length; i++) {
//     // If a field is empty...
//     if (y[i].value == "") {
//       // add an "invalid" class to the field:
//       y[i].className += " invalid";
//       // and set the current valid status to false:
//       valid = false;
//     }
//   }
//   // If the valid status is true, mark the step as finished and valid:
//   if (valid) {
//     document.getElementsByClassName("step")[currentTab].className += " finish";
//   }
//   return valid; // return the valid status
// }

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class to the current step:
  x[n].className += " active";
}
      
</script>

	  
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	  

<script>
  $('#add1').click(function(e){
		e.preventDefault();
		var quantity1 = $('#quantity1').val();
		quantity1++;
		$('#quantity1').val(quantity1);
	});
	$('#minus1').click(function(e){
		e.preventDefault();
		var quantity1 = $('#quantity1').val();
		if(quantity1 > 1){
			quantity1--;
		}
		$('#quantity1').val(quantity1);
	});

  $('#add2').click(function(e){
		e.preventDefault();
		var quantity2 = $('#quantity2').val();
		quantity2++;
		$('#quantity2').val(quantity2);
	});
	$('#minus2').click(function(e){
		e.preventDefault();
		var quantity2 = $('#quantity2').val();
		if(quantity2 > 1){
			quantity2--;
		}
		$('#quantity2').val(quantity2);
	});

  $('#add3').click(function(e){
		e.preventDefault();
		var quantity3 = $('#quantity3').val();
		quantity3++;
		$('#quantity3').val(quantity3);
	});
	$('#minus3').click(function(e){
		e.preventDefault();
		var quantity3 = $('#quantity3').val();
		if(quantity3 > 1){
			quantity3--;
		}
		$('#quantity3').val(quantity3);
	});

  $('#add4').click(function(e){
		e.preventDefault();
		var quantity4 = $('#quantity4').val();
		quantity4++;
		$('#quantity4').val(quantity4);
	});
	$('#minus4').click(function(e){
		e.preventDefault();
		var quantity4 = $('#quantity4').val();
		if(quantity4 > 1){
			quantity4--;
		}
		$('#quantity4').val(quantity4);
	});

  $('#add5').click(function(e){
		e.preventDefault();
		var quantity5 = $('#quantity5').val();
		quantity5++;
		$('#quantity5').val(quantity5);
	});
	$('#minus5').click(function(e){
		e.preventDefault();
		var quantity5 = $('#quantity5').val();
		if(quantity5 > 1){
			quantity5--;
		}
		$('#quantity5').val(quantity5);
	});

  $('#add6').click(function(e){
		e.preventDefault();
		var quantity6 = $('#quantity6').val();
		quantity6++;
		$('#quantity6').val(quantity6);
	});
	$('#minus6').click(function(e){
		e.preventDefault();
		var quantity6 = $('#quantity6').val();
		if(quantity6 > 1){
			quantity6--;
		}
		$('#quantity6').val(quantity6);
	});

  $('#add7').click(function(e){
		e.preventDefault();
		var quantity7 = $('#quantity7').val();
		quantity7++;
		$('#quantity7').val(quantity7);
	});
	$('#minus7').click(function(e){
		e.preventDefault();
		var quantity7 = $('#quantity7').val();
		if(quantity7 > 1){
			quantity7--;
		}
		$('#quantity7').val(quantity7);
	});

  $('#add8').click(function(e){
		e.preventDefault();
		var quantity8 = $('#quantity8').val();
		quantity8++;
		$('#quantity8').val(quantity8);
	});
	$('#minus8').click(function(e){
		e.preventDefault();
		var quantity8 = $('#quantity8').val();
		if(quantity8 > 1){
			quantity8--;
		}
		$('#quantity8').val(quantity8);
	});

  $('#add9').click(function(e){
		e.preventDefault();
		var quantity9 = $('#quantity9').val();
		quantity9++;
		$('#quantity9').val(quantity9);
	});
	$('#minus9').click(function(e){
		e.preventDefault();
		var quantity9 = $('#quantity9').val();
		if(quantity9 > 1){
			quantity9--;
		}
		$('#quantity9').val(quantity9);
	});


  // captain code

</script>



<?php
	  
	  
//	 COPY SITE KEY = 6Ld68FIbAAAAADqOVyGSBYBdpoeSg7FJERN03T2X
//		 
//	 COPY SECRET KEY = 6Ld68FIbAAAAAPdpNBB2vnByXi_m2Hhno_pXR73R
	  
?>
  </body>
</html>