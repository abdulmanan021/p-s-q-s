<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- My Custom CSS -->
    <link href="assets/extracss/mycss.css" rel="stylesheet">

    <!-- Jquery -->
    <script src="jquery/jquery.min.js"></script>

    <title>P's & Q's Printing</title>

  </head>
  <body>

    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <img src="assets/images/logo.png" class="img-fluid" width="300">
          <h1 class="mt-5 mb-5 fw-bold">Thank you for Quotation request</h1>
        </div>
      </div>
    </div>

    <div class="container-fluid pt-5 pb-5" style="background-color: #fcb317;">
      <div class="row">
        <div class="col-md-12 text-center">
          <h1 class="fw-bold">Quotation Request Confirmation</h1>
          <p class="mt-3">We received your quotation request, we will get back to you ASAP.</p>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row mt-5">
        <div class="col-md-5">
          <h3 class="fw-bold">Personal Information</h3>
          <hr class="hrcolr">
          <div class="d-flex justify-content-between">
            <div class="col-md-6">
              <h5 class="fw-bold">Name:</h5>
            </div>
            <div class="col-md-6">
              <p>John Doe</p>
            </div>
          </div>

          <div class="d-flex mt-3 justify-content-between">
            <div class="col-md-6">
              <h5 class="fw-bold">Email:</h5>
            </div>
            <div class="col-md-6">
              <p>example@email.com</p>
            </div>
          </div>

          <div class="d-flex mt-3 justify-content-between">
            <div class="col-md-6">
              <h5 class="fw-bold">Phone Number:</h5>
            </div>
            <div class="col-md-6">
              <p>202-555-0194</p>
            </div>
          </div>
        </div>
      </div>

      <h3 class="fw-bold text-center mt-5">Product Details</h3>
      <hr class="mx-auto hrcolr">
      <div class="row mt-2">
        <div class="col-md-4 mt-3">
          <div class="card imgborder1">
            <img src="assets/images/quote/shirt.png" class="img-fluid imgborder1">
            <div class="card-footer pt-3" style="background-color: transparent; border: transparent;">
              <div class="d-flex">
                <h6 class="fw-bold col">Name:</h6>
                <p class="col">T-Shirt</p>
              </div>
              <div class="d-flex ">
                <h6 class="fw-bold col">Quantity:</h6>
                <p class="col">3</p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4 mt-3">
          <div class="card imgborder1">
            <img src="assets/images/quote/blackshirt.png" class="img-fluid imgborder1">
            <div class="card-footer pt-3" style="background-color: transparent; border: transparent;">
              <div class="d-flex">
                <h6 class="fw-bold col">Name:</h6>
                <p class="col">Shirt</p>
              </div>
              <div class="d-flex ">
                <h6 class="fw-bold col">Quantity:</h6>
                <p class="col">1</p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4 mt-3">
          <div class="card imgborder1">
            <img src="assets/images/quote/towel.png" class="img-fluid imgborder1">
            <div class="card-footer pt-3" style="background-color: transparent; border: transparent;">
              <div class="d-flex">
                <h6 class="fw-bold col">Name:</h6>
                <p class="col">Towel</p>
              </div>
              <div class="d-flex ">
                <h6 class="fw-bold col">Quantity:</h6>
                <p class="col">1</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <h3 class="fw-bold text-center mt-5">Upload Graphics</h3>
      <hr class="mx-auto hrcolr">
      <div class="row">

        <div class="col-md-4 mt-3 text-center">
          <img src="assets/images/quote/shirt.png" class="img-fluid imgborder1" width="200">
        </div>
        <div class="col-md-4 mt-3 text-center">
          <img src="assets/images/quote/blackshirt.png" class="img-fluid imgborder1" width="200">
        </div>
        <div class="col-md-4 mt-3 text-center">
          <img src="assets/images/quote/towel.png" class="img-fluid imgborder1" width="200">
        </div>
      </div>

      <div class="row mt-5 mb-5">
        <div class="col-md-6 mt-3 text-center">
          <img src="assets/images/logo.png" class="img-fluid" width="300">
        </div>
        <div class="col-md-6 mt-3 my-auto">
          <div class="d-flex">
            <h5 class="fw-bold">Name:</h5>&nbsp;&nbsp;
            <p>John Doe</p>
          </div>

          <div class="d-flex mt-2">
            <h5 class="fw-bold">Email:</h5>&nbsp;&nbsp;
            <p>example@email.com</p>
          </div>

          <div class="d-flex mt-2">
            <h5 class="fw-bold">Address:</h5>&nbsp;&nbsp;
            <p>Address here</p>
          </div>
        </div>
      </div>
    </div>


  </body>
</html>