<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- My Custom CSS -->
    <link href="assets/extracss/mycss.css" rel="stylesheet">

    <!-- Jquery -->
    <script src="jquery/jquery.min.js"></script>

    <title>P's & Q's Printing</title>

  </head>
  <body>

   
    <div class="container-fluid navbg navbar-pos pt-2 pb-3">
			
			<div class="row justify-content-between">
				
				<div class="col-md-6 d-flex">
					<a class="navbar-brand" href="">
						<img src="assets/images/logo.png" class="img-fluid" width="160">
					  </a>
					<a class="nav-link d-flex ml-auto" href="tel">
						<?php /*?><img src="assets/images/callicon.png" class="img-fluid" width="30"><?php */?>
						<p class="text-white my-auto p-2">202-555-0194</p>
					</a>
				</div>
				<div class="col-md-4 nodsp">
					<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
					  <div class="carousel-inner">
						<div class="carousel-item active">
							<p class="text-justify text-white">
								Ps and Qs is world best printing service, Professional staff and qualitywork delivered. 
							</p>
							<div class="d-flex text-white justify-content-between">
								<h6 class="fw-bold my-auto">John M</h6>
								<p class="my-auto">CEO</p>
								<p class="my-auto">Q Mobile</p>
							</div>
						</div>
						<div class="carousel-item">
						  <p class="text-justify text-white">
								Ps and Qs is world best printing service, Professional staff and qualitywork delivered. 
							</p>
							<div class="d-flex text-white justify-content-between">
								<h6 class="fw-bold my-auto">John M</h6>
								<p class="my-auto">CEO</p>
								<p class="my-auto">Q Mobile</p>
							</div>
						</div>
						<div class="carousel-item">
						  <p class="text-justify text-white">
								Ps and Qs is world best printing service, Professional staff and qualitywork delivered. 
							</p>
							<div class="d-flex text-white justify-content-between">
								<h6 class="fw-bold my-auto">John M</h6>
								<p class="my-auto">CEO</p>
								<p class="my-auto">Q Mobile</p>
							</div>
						</div>
					  </div>
					  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true" style="visibility: hidden;"></span>
						<span class="visually-hidden">Previous</span>
					  </button>
					  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true" style="visibility: hidden;"></span>
						<span class="visually-hidden">Next</span>
					  </button>
					</div>
				</div>
			
			</div>
          
          <?php /*?><button class="navbar-toggler navbar-light bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
            <ul class="navbar-nav">
              <li class="nav-item my-auto">
                <a href="#" class="nav-link text-white aboutbtn">About Us</a>
              </li>
              <li class="nav-item my-auto">
                <a href="#" class="nav-link text-white faqbtn">FAQ's</a>
              </li>
              <li class="nav-item my-auto">
                <a href="#" class="nav-link text-white contactbtn">Contact Us</a>
              </li>
            </ul>
          </div><?php */?>
        </div>


    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 px-0">
              <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>
                  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="4" aria-label="Slide 5"></button>
                  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="5" aria-label="Slide 6"></button>
                </div>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="assets/images/choose.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-md-block position-absolute top-50 start-0 ">
                      <?php /*?><h2 class=" fw-bold">Choose Garments</h2><?php */?>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="assets/images/upload.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-md-block position-absolute top-50 start-0 ">
                      <?php /*?><h2 class=" fw-bold">Upload Graphics</h2><?php */?>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="assets/images/personal.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-md-block position-absolute top-50 start-0 ">
                      <?php /*?><h2 class="fw-bold">Personal Information</h2><?php */?>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="assets/images/confirmation.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-md-block position-absolute top-50 start-0 ">
                      <?php /*?><h2 class=" fw-bold">Design Confirmation</h2><?php */?>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="assets/images/payment.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-md-block position-absolute top-50 start-0 ">
                      <?php /*?><h2 class=" fw-bold">Payment</h2><?php */?>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="assets/images/pickup.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-md-block position-absolute top-50 start-0 ">
                      <?php /*?><h2 class=" fw-bold">Shipping</h2><?php */?>
                    </div>
                  </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>
              <div class="row slider-content slider-content1 slider-content2 slider-content3 justify-content-end">
                <!-- <div class="col-md-5 my-auto nodsp">
                  <h2 class="fw-bold text-white">INNOVATION IN PRINTING</h2>
                  <p class="text-justify text-white">
                    In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.
                  </p>
                </div> -->
                <div class="col-lg-6 col-md-6 col-xl-4 margintop1 margintop2 margintop3 margintop4">
                  <div class="card pt-2 pb-2 cardbg" style="z-index: 9">
                    <h4 class="fw-bold text-center">Quoting Process</h4>
                    <?php /*?><hr class="mx-auto hrcolr" style="margin-top: -5px; margin-bottom: -5px;"><?php */?>
                    <ul class="liststyle mt-2">
                      <li>Choose Garments</li>
                      <li>Upload Graphics</li>
                      <li>Personal Information</li>
                      <li>Design Confirmation</li>
                      <li>Payment</li>
                      <li>Shipping</li>
                    </ul>
                    <a href="quote.php" class="btn btnsubmit w-50 mt-1 mb-1 mx-auto text-white">Get Quote</a>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!--  ABOUT US -->
        <div class="row mt-5 bgimg margintop" id="aboutus">
            <div class="col-md-6">
                <img src="assets/images/about.png" class="img-fluid">
            </div>
            <div class="col-md-6 my-auto">
                <h2 class="fw-bold">About Us</h2>
                <hr class="hrcolr">
                <p class="text-justify">
                    When your needs go beyond a simple print job, it’s time to think creatively, and look for a true partner in innovation. PS & QS is an award-winning, multi-dimensional print provider of packaging, labeling, wall art, and transfers. What makes us unique is what’s under our roof. We feature both conventional, and UV offset, flexo, digital, and screen printing in one facility. This combination allows us to deliver some of the most unique, and creative print solutions available.
                </p>
            </div>
        </div>

        <!--  What do we Offer -->
        <?php /*?><h2 class="fw-bold text-center mt-5">What do we Offer?</h2>
          <hr class="mx-auto hrcolr">
        <div class="row">
          <div class="col-md-4 mt-3">
            <div class="card p-2 cardshadow">
              <h6 class="fw-bold">T-Shirt Printing</h6>
              <img src="assets/images/tshirt.png" class="img-fluid mt-3 mb-3" width="70">
              <p>
                In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.
              </p>
            </div>
          </div>
          <div class="col-md-4 mt-3">
            <div class="card p-2 cardshadow">
              <h6 class="fw-bold">Bag Printing</h6>
              <img src="assets/images/bag.png" class="img-fluid mt-3 mb-3" width="70">
              <p>
                In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.
              </p>
            </div>
          </div>
          <div class="col-md-4 mt-3">
            <div class="card p-2 cardshadow">
              <h6 class="fw-bold">Cards Printing</h6>
              <img src="assets/images/cards.png" class="img-fluid mt-3 mb-3" width="70">
              <p>
                In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.
              </p>
            </div>
          </div>
          <div class="col-md-4 mt-3">
            <div class="card p-2 cardshadow">
              <h6 class="fw-bold">Paperboard Packaging</h6>
              <img src="assets/images/paperboard.png" class="img-fluid mt-3 mb-3" width="70">
              <p>
                In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.
              </p>
            </div>
          </div>
          <div class="col-md-4 mt-3">
            <div class="card p-2 cardshadow">
              <h6 class="fw-bold">Decals and Transfers</h6>
              <img src="assets/images/decals.png" class="img-fluid mt-3 mb-3" width="70">
              <p>
                In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.
              </p>
            </div>
          </div>
          <div class="col-md-4 mt-3">
            <div class="card p-2 cardshadow">
              <h6 class="fw-bold">Marketing Colletral</h6>
              <img src="assets/images/marketing.png" class="img-fluid mt-3 mb-3" width="70">
              <p>
                In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.
              </p>
            </div>
          </div>
        </div><?php */?>

        <!--  Gallery -->
        <div class="row bgimg">
          <h2 class="fw-bold text-center mt-5">Gallery
            <hr class="mx-auto hrcolr">
          </h2>
          <div class="col-md-3 mt-3">
            <div class="card" style="border: none;">
              <img src="assets/images/gallery/g1.png" class="img-fluid img-thumbnail">
            </div>
          </div>
          <div class="col-md-3 mt-3">
            <div class="card" style="border: none;">
              <img src="assets/images/gallery/g2.png" class="img-fluid img-thumbnail">
            </div>
          </div>
          <div class="col-md-3 mt-3">
            <div class="card" style="border: none;">
              <img src="assets/images/gallery/g3.png" class="img-fluid img-thumbnail">
            </div>
          </div>
          <div class="col-md-3 mt-3">
            <div class="card" style="border: none;">
              <img src="assets/images/gallery/g4.png" class="img-fluid img-thumbnail">
            </div>
          </div>
          <div class="col-md-3 mt-3">
            <div class="card" style="border: none;">
              <img src="assets/images/gallery/g5.png" class="img-fluid img-thumbnail">
            </div>
          </div>
          <div class="col-md-3 mt-3">
            <div class="card" style="border: none;">
              <img src="assets/images/gallery/g6.png" class="img-fluid img-thumbnail">
            </div>
          </div>
          <div class="col-md-3 mt-3">
            <div class="card" style="border: none;">
              <img src="assets/images/gallery/g7.png" class="img-fluid img-thumbnail">
            </div>
          </div>
          <div class="col-md-3 mt-3">
            <div class="card" style="border: none;">
              <img src="assets/images/gallery/g8.png" class="img-fluid img-thumbnail">
            </div>
          </div>
        </div>

		
		<!--  FAQ -->
        <h2 class="fw-bold text-center mt-5" id="faq">Frequently Asked Questions</h2>
            <hr class="mx-auto hrcolr">
        <div class="row">
            <?php /*?><p class="mt-2 mb-5 text-center">See frequently asked questions from our beloved customers</p><?php */?>
            <div class="col-md-6 my-auto">
                <div class="accordion" id="accordionExample">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                          <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Do You Charge for per Revisions?
                          </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            Customer happiness is our priority, offering them the best. For small improvements and edits to designs submitted for review and feedback, we do not charge.
                          </div>
                        </div>
                      </div>
                    <div class="accordion-item">
                      <h2 class="accordion-header" id="headingTwo">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            In what file formats do you print?
                        </button>
                      </h2>
                      <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            Based on consumer preferences, we deliver projects in a variety of file formats. Let us know the formats you choose for prefer at the start of the print.
                        </div>
                      </div>
                    </div>
                    <div class="accordion-item">
                      <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            How do you do about pricing?
                        </button>
                      </h2>
                      <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            Our pricing choices are versatile and depend on the market model in which you deal – a particular resource model, project base, per hour, etc.
                        </div>
                      </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingfour">
                          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                            Can You customize my existing designs?
                          </button>
                        </h2>
                        <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            Yes, We will be happy to do that!
                          </div>
                        </div>
                      </div>
                  </div>
            </div>
            <div class="col-md-6">
                <img src="assets/images/faq.png" class="img-fluid">
            </div>
        </div>
		
        <!--  Contact Us -->
        <?php /*?><h2 class="fw-bold text-center mt-5" id="conatctus">Contact Us</h2>
          <hr class="mx-auto hrcolr">
        <div class="row">
          <div class="col-md-6 mt-3">
            <img src="assets/images/contact.png" class="img-fluid">
          </div>
          <div class="col-md-6 mt-3">
            <h3 class="txtcolr fw-bold mb-5 d-block">Drop Us a line</h3>
            <?php 
            error_reporting(0);

                if(isset($_POST['submit']))
                {
                    $to = "david.markk611@gmail.com";

                    $subject = "Message sent from P's&Q's by: ".$_POST['name'];
                    
                    $message = $_POST['message'];
                    
                    $header = $_POST['email'];

                    $header .= "MIME-Version: 1.0\r\n";
                    $header .= "Content-type: text/html\r\n";
                    
                    $sendmail = mail ($to,$subject,$message,$header);
                    
                    if( $sendmail == true )
                    {
                        echo "Message sent successfully...";
                    }
                    else
                    {
                        echo "Message could not be sent...";
                    }
                }
            
            ?>
            <!--  Contact FORM -->
            <form action="" method="post">
              <input type="text" class="form-control brdrad" name="name" placeholder="NAME" Required>
              <input type="email" class="form-control brdrad mt-2" name="email" placeholder="EMAIL" Required>
              <textarea class="form-control brdrad mt-2" rows="3" name="message" placeholder="MESSAGE" Required></textarea>
              <input type="submit" name="submit" class="btn text-white p-2 d-block w-50 mt-5 mx-auto btnsubmit" value="Submit">
                
             
            </form>


          </div>
        </div><?php */?>
    </div>

    <!--  Footer -->
    <footer>
      <div class="container-fluid pt-5 pb-5 mt-5 footbg">
        <div class="row justify-content-between">
          <div class="col-md-3">
            <a href="#" class="homebtn">
              <img src="assets/images/logo.png" class="img-fluid" width="200">
            </a>
          </div>
          <?php /*?><div class="col-md-3">
            <h5 class="fw-bold mt-2 mb-2">Quick Links</h5>
            <a href="#" class="nav-link text-white homebtn">Home</a>
            <a href="#" class="nav-link text-white aboutbtn">About Us</a>
            <a href="#" class="nav-link text-white faqbtn">FAQ's</a>
            <a href="#" class="nav-link text-white contactbtn">Contact Us</a>
          </div>
          <div class="col-md-3">
            <h5 class="fw-bold mt-2 mb-2">Contact us</h5>
            <p class="text-white text-justify">Phone: 202-555-0194</p>
            <p class="text-white text-justify">Email: example@email.com</p>
            <address>
              <p class="text-white">Address: Your address here</p>
            </address>
          </div><?php */?>
          <div class="col-md-6">
            <h5 class="fw-bold mt-2 mb-2 text-center">Follow Us</h5>
            <div class="row justify-content-center">
              <div class="col-md-2 text-center mt-3">
                <a href="#"><img src="assets/images/icons/facebook.png" class="img-fluid" width="50"></a>
              </div>
              <div class="col-md-2 text-center mt-3">
                <a href="#"><img src="assets/images/icons/twitter.png" class="img-fluid" width="50"></a>
              </div>
              <div class="col-md-2 text-center mt-3">
                <a href="#"><img src="assets/images/icons/instagram.png" class="img-fluid" width="50"></a>
              </div>
              <div class="col-md-2 text-center mt-3">
                <a href="#"><img src="assets/images/icons/pintrest.png" class="img-fluid" width="50"></a>
              </div>
              <div class="col-md-2 text-center mt-3">
                <a href="#"><img src="assets/images/icons/whatsapp.png" class="img-fluid" width="50"></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>

    <script>
      $(document).ready(function() {
      $(".homebtn").click(function() {
          $('html, body').animate({
              scrollTop: $("#home").offset().top
          }, 1000);
      });

      $(".aboutbtn").click(function() {
          $('html, body').animate({
              scrollTop: $("#aboutus").offset().top
          }, 1000);
      });

      $(".faqbtn").click(function() {
          $('html, body').animate({
              scrollTop: $("#faq").offset().top
          }, 1000);
      });

      $(".contactbtn").click(function() {
          $('html, body').animate({
              scrollTop: $("#conatctus").offset().top
          }, 1000);
      });

      });
    </script>

<?php
//include 'db_connection.php';
//$conn = OpenCon();
//echo "Connected Successfully";
//CloseCon($conn);
?>

  </body>
</html>